namespace DeMasterProCloud.DataModel.Device;

public class VmsCameraModel
{
    public string CameraId { get; set; }
    public string Name { get; set; }
    public string UrlStream { get; set; }
    public int VideoLength { get; set; }
}