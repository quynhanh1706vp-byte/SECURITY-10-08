using System;

namespace DeMasterProCloud.DataModel.EventLog
{
    public class EventLogModelHVQY
    {
        public string MaSoHocVien { get; set; }
        public int LoaiDangKi { get; set; }
        public int Tuan { get; set; }
        public string VaoMuon { get; set; }
    }
}