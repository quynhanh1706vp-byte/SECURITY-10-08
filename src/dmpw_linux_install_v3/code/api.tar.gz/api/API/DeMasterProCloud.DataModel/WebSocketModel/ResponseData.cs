namespace DeMasterProCloud.DataModel.WebSocketModel
{
    public class ResponseData
    {
        public string Response { get; set; }
        public string Result { get; set; }
    }
    public class RequestData
    {
        public string Request { get; set; }
    }
}