namespace DeMasterProCloud.DataModel.Attendance
{
    public class LeaveSettingModel
    {
        public int Id { get; set; }
        public int NumberDayOffYear { get; set; }
        public int NumberDayOffPreviousYear { get; set; }
    }
}