namespace DeMasterProCloud.DataModel.Meeting;

public class VisitForMeeting
{
    public int Id { get; set; }
    public string VisitorName { get; set; }
    public string Position { get; set; }
    public string Phone { get; set; }
    public string Email { get; set; }
    public string Address { get; set; }
}