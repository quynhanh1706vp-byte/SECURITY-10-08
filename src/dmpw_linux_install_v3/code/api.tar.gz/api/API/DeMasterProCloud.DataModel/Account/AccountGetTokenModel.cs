namespace DeMasterProCloud.DataModel.Account
{
    public class AccountGetTokenModel
    {
        public string Username { get; set; }
        public string Hash { get; set; }
    }
}