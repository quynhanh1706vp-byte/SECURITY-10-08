namespace DeMasterProCloud.DataModel.Setting;

public class LanguageModel
{
    public int Id { get; set; }
    public string Tag { get; set; }
}

public class LanguageDetailModel
{
    public int Id { get; set; }
    public string Tag { get; set; }
    public string Name { get; set; }
}