namespace DeMasterProCloud.DataModel.Department;

public class DepartmentFilterModel : FilterModel
{
    public string Search { get; set; }
}